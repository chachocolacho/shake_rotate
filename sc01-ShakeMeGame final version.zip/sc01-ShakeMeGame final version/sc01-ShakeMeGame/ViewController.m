//
//  ViewController.m
//  sc01-ShakeMeGame
//
//  Created by user on 10/2/17.
//  Copyright © 2017 Cha. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSTimer *timer;
    int     counter;
    int     score;
    int     gameMode; //1- being played
    // 2 - game over
}
@property (weak, nonatomic) IBOutlet UIButton *btnStart;
@property (weak, nonatomic) IBOutlet UILabel *lblTimer;
@property (weak, nonatomic) IBOutlet UILabel *lblScore;
@property (weak, nonatomic) IBOutlet UILabel *lblLevels;
@property (weak, nonatomic) IBOutlet UISegmentedControl *sgmLevels;
@property (weak, nonatomic) IBOutlet UISwitch *swtch;
@property (weak, nonatomic) IBOutlet UIButton *btnSwitch;
@property (weak, nonatomic) IBOutlet UILabel *lblSwitch;



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    score =0;
    counter =10;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)LevelPicked:(id)sender {
    if (self.sgmLevels.selectedSegmentIndex == 0){
        self.lblLevels.text = @"you picked level 1";
        counter = 10;
        self.lblTimer.text = [NSString stringWithFormat:@"%i", counter];
    }
    else if (self.sgmLevels.selectedSegmentIndex == 1){
        counter = 20;
        self.lblTimer.text = [NSString stringWithFormat:@"%i", counter];
        self.lblLevels.text = @"You picked level 2";
    }
    else if (self.sgmLevels.selectedSegmentIndex == 2){
        self.lblLevels.text = @"You picked level 3";
        counter = 30;
        self.lblTimer.text = [NSString stringWithFormat:@"%i", counter];
    }
}

- (IBAction)startGamePressed:(id)sender {
    if (score ==0 ){
        
        gameMode = 1; //we started the game
        self.lblTimer.text = [NSString stringWithFormat:@"%i", counter];
        // create a timer
        timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(startCounter) userInfo:nil repeats:YES];
        self.btnStart.enabled = NO;
        self.sgmLevels.enabled = NO;
    }
    if (counter ==0){ // reset the timer to 10
        score =0;
        counter = 10;
        self.lblTimer.text = [NSString stringWithFormat:@"%i", counter];
        self.lblScore.text = [NSString stringWithFormat:@"%i", score];
    }
    
    
}
- (IBAction)SwitchControlChanged:(id)sender {
    if (self.swtch.on){
        self.lblSwitch.text = @"Shake";
        self.btnSwitch.enabled = YES;
    }
    else {
        self.lblSwitch.text = @"Rotate";
        self.btnSwitch.enabled = NO;
    }
    
}

-(void)startCounter {
    //decrement the counter
    counter -=1;
    
    self.lblTimer.text = [NSString stringWithFormat:@"%i", counter];
    if (counter ==0){
        [timer invalidate];
        gameMode = 2; // game is over
        
        //toggle the start button to restart, enable it
        [self.btnStart setTitle:@"Restart" forState:UIControlStateNormal];
        self.btnStart.enabled = YES;
        self.sgmLevels.enabled = YES;
    }
}

-(void)motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event{
    if (event.subtype == UIEventSubtypeMotionShake){
        if (gameMode ==1 && [_lblSwitch.text  isEqual: @"Shake"]){
            //increment the score
            score +=1;
            self.lblScore.text = [NSString stringWithFormat:@"%i", score];
        }
    }
}
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator{
    if (gameMode ==1 && [_lblSwitch.text  isEqual: @"Rotate"]) {
        score += 1;
        self.lblScore.text = [NSString stringWithFormat:@"%i", score];
    }
}

@end
