//
//  AppDelegate.h
//  sc01-ShakeMeGame
//
//  Created by user on 10/2/17.
//  Copyright © 2017 Cha. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

